# Create services
1. Settear java 11
    ```shell
    mvn --version
    /usr/libexec/java_home -V
    export JAVA_HOME=/usr/local/Cellar/openjdk@11/11.0.10/libexec/openjdk.jdk/Contents/Home
    mvn package
    ```