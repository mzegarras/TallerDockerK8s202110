package com.odybank.customers.service;

public interface CustomerService {

    String getNombres(int id);
    String getCuenta(int id);
    int calcular(int n1,int n2);

}
