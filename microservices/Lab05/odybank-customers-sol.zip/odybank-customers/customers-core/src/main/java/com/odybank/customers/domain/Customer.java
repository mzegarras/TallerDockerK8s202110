package com.odybank.customers.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Customer {
    private String id;
    private String nombres;
    private String paterno;
}
